**Markdown Test File**

1. Load the page
1. See the source
1. Use a browser extension for Markdown
1. See the formatted page
